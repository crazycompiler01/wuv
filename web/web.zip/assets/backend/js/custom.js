$(document).ready(function(){
	
  //Dropdown menu - select2 plug-in
  $(".select2").select2();
});

